﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.IO;

namespace MPG123Wrapper
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public IntPtr handle_mpg;
        public IntPtr errPtr;
        public IntPtr rate;
        public IntPtr channels;
        public IntPtr encoding;
        public IntPtr id3v1;
        public IntPtr id3v2;

        public IntPtr done;

        private void button1_Click(object sender, EventArgs e)
        {
            MPGImport.mpg123_init();
            string s =txtMP3.Text;
            handle_mpg = MPGImport.mpg123_new(null, errPtr);
            int x = MPGImport.mpg123_open(handle_mpg, s);
            MPGImport.mpg123_getformat(handle_mpg, out rate, out channels, out encoding);

            int _rate = rate.ToInt32();
            int _channels = channels.ToInt32();
            int _encoding = encoding.ToInt32();

            txtRate.Text = _rate.ToString();
            txtChannels.Text = _channels.ToString();

            MPGImport.mpg123_id3(handle_mpg, out id3v1, out id3v2);
            MPGImport.mpg123_id3v1 MP3Data = new MPGImport.mpg123_id3v1();
            MP3Data = (MPGImport.mpg123_id3v1)Marshal.PtrToStructure(id3v1, typeof(MPGImport.mpg123_id3v1));

            txtArtist.Text = new string(MP3Data.artist);
            txtTitle.Text = new string(MP3Data.title);

            MPGImport.mpg123_format_none(handle_mpg);
            MPGImport.mpg123_format(handle_mpg, _rate, _channels, _encoding);

            int FrameSize = MPGImport.mpg123_outblock(handle_mpg);

            FileStream fsOut = new FileStream(txtPCM.Text, FileMode.Create, FileAccess.Write);

            byte[] Buffer = new byte[FrameSize];
            while (0 == MPGImport.mpg123_read(handle_mpg, Buffer, FrameSize, out done))
            {
                fsOut.Write(Buffer, 0, FrameSize);
            }

            fsOut.Close();

            MessageBox.Show("OK");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (openMP3.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                txtMP3.Text = openMP3.FileName;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (savePCM.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                txtPCM.Text = savePCM.FileName;
        }
    }
}
